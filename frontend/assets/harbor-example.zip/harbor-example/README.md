# Benchsquare synthetic example

This package demonstrates downloading Harbor archives in the submission UI. It is not a participant submission or an evaluation result.
