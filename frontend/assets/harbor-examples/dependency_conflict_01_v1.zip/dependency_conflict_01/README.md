# dependency_conflict_01

Synthetic Benchsquare submission fixture.
Revision: v1

This archive illustrates submission and review history, not a real participant deliverable.
