# thermal_boundary_resubmit_03

Synthetic Benchsquare submission fixture.
Revision: v2

This archive illustrates submission and review history, not a real participant deliverable.
