#!/bin/bash
set -eu
python - <<'PYCODE'
import json
cases=json.load(open('/workspace/cases.json'))
results=[]
for c in cases:
 q=c['conductivity']*(c['left_k']-c['right_k'])/c['length_m']
 results.append({'name':c['name'],'heat_flux':q,'inward_left':q,'inward_right':-q})
json.dump(results,open('/workspace/results.json','w'),indent=2)
PYCODE
