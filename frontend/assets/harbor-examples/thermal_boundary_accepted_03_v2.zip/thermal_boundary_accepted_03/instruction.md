# Thermal boundary verification

Read /workspace/cases.json. For each case, calculate steady-state heat flux q = k * (T_left - T_right) / length, using kelvin and meters. Write /workspace/results.json as a list of objects with name and heat_flux.

Positive heat flux points from the left boundary into the domain. An adiabatic boundary has zero normal flux. The two boundary fluxes must balance within 1e-6. Include inward_left and inward_right in each result.
