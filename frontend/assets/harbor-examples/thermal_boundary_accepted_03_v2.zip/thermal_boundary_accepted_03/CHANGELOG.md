# Submission history

v2: Clarify boundary conventions, add boundary cases and an energy conservation assertion with tolerance 1e-6.
