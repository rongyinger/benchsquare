#!/bin/sh
mkdir -p /logs/verifier
if [ "$(cat /workspace/result.txt 2>/dev/null)" = "hello harbor" ]; then echo 1 > /logs/verifier/reward.txt; else echo 0 > /logs/verifier/reward.txt; fi
