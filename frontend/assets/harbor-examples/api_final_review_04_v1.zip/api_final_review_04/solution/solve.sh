#!/bin/sh
mkdir -p /workspace
printf "hello harbor" > /workspace/result.txt
