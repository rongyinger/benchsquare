# Submission history

v2: Correct the currency unit conversion; missing-value handling and reference consistency remain unresolved and are recorded in review feedback.
