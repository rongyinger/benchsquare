#!/bin/bash
set -eu
printf "hello harbor\n" > /workspace/result.txt
