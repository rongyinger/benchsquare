# Synthetic demonstration task

Write the text `hello harbor` to `/workspace/result.txt`.
This package is a Benchsquare UI demonstration fixture.
