# Submission history

v1: Initial task package with baseline instructions and verifier.
