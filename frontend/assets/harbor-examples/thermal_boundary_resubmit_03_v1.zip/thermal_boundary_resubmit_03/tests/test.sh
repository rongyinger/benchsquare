#!/bin/bash
set -eu
mkdir -p /logs/verifier
if python - <<'PYCODE'
import json
results={r['name']:r for r in json.load(open('/workspace/results.json'))}
assert abs(results['fixed_temperature']['heat_flux']-40)<1e-6
PYCODE
then echo 1 > /logs/verifier/reward.txt
else echo 0 > /logs/verifier/reward.txt
fi
