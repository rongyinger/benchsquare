# Thermal boundary verification

Read /workspace/cases.json. For each case, calculate steady-state heat flux q = k * (T_left - T_right) / length, using kelvin and meters. Write /workspace/results.json as a list of objects with name and heat_flux.

The verifier checks the fixed-temperature case.
